#ifndef fileheader_h
#define fileheader_h
void showsum(int a, int b);
#endif // !fileheader.h

