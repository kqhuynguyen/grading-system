#include<string>
using namespace std;
#ifndef fileheader_h
#define fileheader_h
void readFileData(string filenamein,string filenameout);
#endif // !fileheader.h