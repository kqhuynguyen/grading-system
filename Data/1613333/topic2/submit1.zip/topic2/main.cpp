#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "fileheader.h"
using namespace std;
int main()
{
	readFileData("input.txt", "output.txt");
	return 0;
}