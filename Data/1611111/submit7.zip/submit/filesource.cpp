#include <iostream>
#include "fileheader.h"
using namespace std;
void showsum(int a,int b)
{
	cout<<"a + b = "<<a+b<<endl
}