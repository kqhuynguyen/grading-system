#include<string>
using namespace std;
#ifndef fileheader_h
#define fileheader_h
void readFileData(float *arr,int &dem);
void process(float *arr, int n);
#endif // !fileheader.h